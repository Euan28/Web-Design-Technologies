<!DOCTYPE html>
<html>
   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title></title>
      <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet">
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      <link href="style.css" media="all" rel="stylesheet" type="text/css">
   </head>
   <body>
      <div class="header">
         <img src="images/logowt.png">
         <p>Disovery Scotland</p>
      </div>
      <div id="wrapper">
         <div id="header-wrapper">
            <div class="container-h" id="header">
               <div id="logo">
                  <h1><img src="images/logogt.png">Welcome to Discovery Scotland</h1>
               </div>
            </div>
            <div class="container-m col-12 col-s-12" id="menu-rop" class="w3-bar w3-red">
               <ul>
                  <li>
                     <a href="home.html" class="w3-hide-small">Home</a>
                  </li>
                  <li>
                     <a href="jobinfo.php" class="w3-hide-small">Job Info</a>
                  </li>
                  <li>
                     <a href="msp.php" class="w3-hide-small">MSP Details</a>
                  </li>
                  <li class="current_page_item">
                     <a class="active" href="rop.php" class="w3-bar-item w3-button">Rate of Pay</a>
                  </li>
				  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="myFunction()">&#9776;</a>
               </ul>
            </div>
         </div>
		 <div id="demo" class="w3-bar-block w3-indigo w3-hide w3-hide-large w3-hide-medium">
		  <a href="home.html" class="w3-bar-item w3-button">Home</a>
		  <a href="jobinfo.php" class="w3-bar-item w3-button">Job Info</a>
		  <a href="msp.php" class="w3-bar-item w3-button">MSP Details</a>
		</div>
         <div class="container-s col-12 col-s-12" id="page">
            <div id="content">
               <div class="post">
                  <p class="ropinfo">Rate of Pay</p>
                  <hr class="ropinfopage">
                  <p class="customerrequest">Please enter job title to reveal rate of pay details for the occupancy entered</p>
                  <input id="mySearchField" name="search" placeholder="Enter Job Title" type="text"><button id="mySearchButton" class="sbmt">Search</button><br>
                  <br>
                  <p class="data"></p>
				  <br><br><br><br><br>
				  <hr class="ropinfopage">
				  <p class="customerrequest">If you wish, there is also graph forms that you can select below</p>
				  <div class="dropdown">
				  <button class="dropbtn">Options:</button>
				  <div class="dropdown-content">
					<a href="chartsd.html">Software Developers</a>
					<a href="chartwd.html">Web Designers/Developers</a>
					<a href="chartrdm.html">Research Development Managers</a>
				  </div>
				</div>
               </div>
			   <div id="lightbox" >
                  <div id="overlay"> </div>
                  <img id="largeImg" src="" alt="" /> 
                  <span id="caption"></span>
                  <span id="close">&times;</span>
               </div>
            </div>
            <div id="sidebar1">
               <div>
                  <h2>Contact Information</h2>
                  <ul class="style2">
                     <li class="first">
                        <p>Not finding what you are looking for or have any questions that you need answering? Feel free to contact us via telephone or email.</p>
                        <p><img src="images/email.png"> info@discoveryscotland.co.uk</p>
                        <p><img src="images/phone.png"> 0141 117 6669</p>
                     </li>
                     <li>
                        <h3>Social Media</h3>
                        <p class="connect">Connect:<img id="myImg" src="images/twitter.png"><img id="myImg2" src="images/insta.png"><img id="myImg3" src="images/fb.png"><img id="myImg4" src="images/youtube.png"></p>
                        <div id="myModal" class="modal">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <span class="close">&times;</span>
                                 <h4>
                                    <center>You are leaving Discovery Scotland's Website to visit our selected Social Media platform?</center>
                                 </h4>
                              </div>
                              <div class="modal-body">
                                 <p>
                                 <center>
                                 Would you like to proceed with this?
                                 <center>
                                 </p>
                                 <button class="yesno" id="yes"><span>Yes</span></button>
                                 <button class="yesno" id="no"><span>No</span></button>
                              </div>
                              <div class="modal-footer">
                                 <h5>&copy; DISCOVERY SCOTLAND 2019</h5>
                              </div>
                           </div>
                        </div>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="footer">
            <p><img src="images/logobt.png">&copy; DISCOVERY SCOTLAND 2019</p>
         </div>
      </div>
      <script>
         $(function() {
         	$(document).on('click', '#mySearchButton', function() {
         		const searchValue = $("#mySearchField").val();
         		if (searchValue.length > 0) {
         			const $data = $('p.data').empty();
         			$.ajax(`http://api.lmiforall.org.uk/api/v1/soc/search?q=${searchValue}`, {
         				method: "GET",
         				dataType: "json",
         			}).done((data) => {
         				if (data.length == 0) return $("<span>", {
         					class: "error",
         					text: "No results found"
         				}).appendTo($data);
         				$("<h4>", {
         					class: "title",
         					text: `Career: ${data[0].title}`
         				}).appendTo($data);
         				const soc = data[0].soc;
         				$.ajax(`http://api.lmiforall.org.uk/api/v1/ashe/estimatePay?soc=${soc}&coarse=false&filters=region%3A11`, {
         					method: 'GET',
         					dataType: "json",
         				}).done((data) => {
         					if (data.length == 0) return $("<span>", {
         						class: "error",
         						text: "No statistics found"
         					}).appendTo($data);
         					for (let i = 0; i < data.series.length; i++) {
         						$("<span>", {
         							class: "espYear",
         							text: `Year: ${data.series[i].year}`
         						}).appendTo($data);
         						$("<span>", {
         							class: "espPay",
         							text: `Pay per week: £${data.series[i].estpay}`
         						}).appendTo($data);
         					}
         				}).fail((error) => {
         					console.error(error);
         				});
         			}).fail((error) => {
         				console.error(error);
         			});
         		}
         	});
         });
         
         var modal = document.getElementById("myModal");
		 
		 var buttonYes = document.getElementById("yes");
		 
		 var buttonNo = document.getElementById("no");
         
         var img = document.getElementById("myImg");
         var img2 = document.getElementById("myImg2");
         var img3 = document.getElementById("myImg3");
         var img4 = document.getElementById("myImg4");
         
         var span = document.getElementsByClassName("close")[0];
         
         img.onclick = function() {
         modal.style.display = "block";
         }
         
         img2.onclick = function() {
         modal.style.display = "block";
         }
         
         img3.onclick = function() {
         modal.style.display = "block";
         }
         
         img4.onclick = function() {
         modal.style.display = "block";
         }
         
         span.onclick = function() {
         modal.style.display = "none";
         }
		 
		 buttonYes.onclick = function() {
		 alert("Now taking you to the selected platform");
		}
         
		 buttonNo.onclick = function() {
		 modal.style.display = "none";
		 }
		 
         window.onclick = function(event) {
         if (event.target == modal) {
         modal.style.display = "none";
         }
         }
		 
		function myFunction() {
		  var x = document.getElementById("demo");
		  if (x.className.indexOf("w3-show") == -1) {
			x.className += " w3-show";
		  } else { 
			x.className = x.className.replace(" w3-show", "");
		  }
		}
      </script>
   </body>
</html>