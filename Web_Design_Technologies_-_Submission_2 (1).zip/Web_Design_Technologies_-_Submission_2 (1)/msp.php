<!DOCTYPE html>
<html>
   <head>
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title></title>
      <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet">
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      <link href="style.css" media="all" rel="stylesheet" type="text/css">
   </head>
   <body>
      <div class="header">
         <img src="images/logowt.png">
         <p>Disovery Scotland</p>
      </div>
      <div id="wrapper">
         <div id="header-wrapper">
            <div class="container-h" id="header">
               <div id="logo">
                  <h1><img src="images/logogt.png">Welcome to Discovery Scotland</h1>
               </div>
            </div>
            <div class="container-m col-12 col-s-12" id="menu-msp" class="w3-bar w3-red">
               <ul>
                  <li>
                     <a href="home.html" class="w3-hide-small">Home</a>
                  </li>
                  <li>
                     <a href="jobinfo.php" class="w3-hide-small">Job Info</a>
                  </li>
                  <li class="current_page_item">
                     <a class="active" href="msp.php" class="w3-bar-item w3-button">MSP Details</a>
                  </li>
                  <li>
                     <a href="rop.php" class="w3-hide-small">Rate of Pay</a>
                  </li>
				  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="myFunction()">&#9776;</a>
               </ul>
            </div>
         </div>
		 <div id="demo" class="w3-bar-block w3-indigo w3-hide w3-hide-large w3-hide-medium">
		  <a href="home.html" class="w3-bar-item w3-button">Home</a>
		  <a href="jobinfo.php" class="w3-bar-item w3-button">Job Info</a>
		  <a href="rop.php" class="w3-bar-item w3-button">Rate of Pay</a>
		</div>
         <div class="container-s col-12 col-s-12" id="page">
            <div id="content">
               <div class="post">
                  <p class="mspinfo">MSP Details</p>
                  <hr class="mspinfopage">
                  <p class="customerrequest">Please enter postcode below to reveal MSP details for the MSP in your enterered area</p>
                  <input id="mySearchField" name="search" placeholder="Enter Postcode" type="text"><button id="mySearchButton" class="sbmt">Search</button><br>
                  <br>
                  <p class="data"></p>
               </div>
			   <div id="lightbox" >
                  <div id="overlay"> </div>
                  <img id="largeImg" src="" alt="" /> 
                  <span id="caption"></span>
                  <span id="close">&times;</span>
               </div>
            </div>
            <div id="sidebar1">
               <div>
                  <h2>Contact Information</h2>
                  <ul class="style2">
                     <li class="first">
                        <p>Not finding what you are looking for or have any questions that you need answering? Feel free to contact us via telephone or email.</p>
                        <p><img src="images/email.png"> info@discoveryscotland.co.uk</p>
                        <p><img src="images/phone.png"> 0141 117 6669</p>
                     </li>
                     <li>
                        <h3>Social Media</h3>
                        <p class="connect">Connect:<img id="myImg" src="images/twitter.png"><img id="myImg2" src="images/insta.png"><img id="myImg3" src="images/fb.png"><img id="myImg4" src="images/youtube.png"></p>
                        <div id="myModal" class="modal">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <span class="close">&times;</span>
                                 <h4>
                                    <center>You are leaving Discovery Scotland's Website to visit our selected Social Media platform?</center>
                                 </h4>
                              </div>
                              <div class="modal-body">
                                 <p>
                                 <center>
                                 Would you like to proceed with this?
                                 <center>
                                 </p>
                                 <button class="yesno" id="yes"><span>Yes</span></button>
                                 <button class="yesno" id="no"><span>No</span></button>
                              </div>
                              <div class="modal-footer">
                                 <h5>&copy; DISCOVERY SCOTLAND 2019</h5>
                              </div>
                           </div>
                        </div>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="footer">
            <p><img src="images/logobt.png">&copy; DISCOVERY SCOTLAND 2019</p>
         </div>
      </div>
      <script>
         $(function() {
              function formatDate(date) {
                  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                  let dayOfMonth = date.getDate();
                  let month = date.getMonth() + 1;
                  let year = date.getFullYear();
                  let hour = date.getHours();
                  let minutes = date.getMinutes();
                  let diffMs = new Date() - date;
                  let diffSec = Math.round(diffMs / 1000);
                  let diffMin = diffSec / 60;
                  let diffHour = diffMin / 60;
                  year = year.toString();
                  month = months[month];
                  dayOfMonth = dayOfMonth < 10 ? '0' + dayOfMonth : dayOfMonth;
                  hour = hour < 10 ? '0' + hour : hour;
                  minutes = minutes < 10 ? '0' + minutes : minutes;
                  if (diffSec < 1) {
                      return 'right now';
                  } else if (diffMin < 1) {
                      return `${diffSec} sec. ago`
                  } else if (diffHour < 1) {
                      return `${diffMin} min. ago`
                  } else {
                      return `${dayOfMonth} ${month} ${year} at ${hour}:${minutes}`
                  }
              }
         
              function findByConstituencyCode(results, constituencyCode) {
                  return results.filter((constituency) => constituency.ConstituencyCode == constituencyCode)[0];
              }
              $(document).on('click', '#mySearchButton', function() {
                  const searchValue = $("#mySearchField").val();
                  if (searchValue.length > 0) {
                      const $data = $('p.data').empty();
                      $.ajax(`https://api.postcodes.io/scotland/postcodes/${searchValue}`, {
                          method: "GET",
                          dataType: "json",
                      }).done((data) => {
                          const constituencyCode = data.result.codes["scottish_parliamentary_constituency"];
                          $.ajax("https://data.parliament.scot/api/constituencies/", {
                              method: 'GET',
                              dataType: "json",
                          }).done((data) => {
                              const constituency = findByConstituencyCode(data, constituencyCode);
                              if (constituency === undefined) return $("<span>", {
                                  class: "error",
                                  text: "No constituency found"
                              }).appendTo($data);
                              $("<h4>", {
                                  class: "title",
                                  text: `Constituency: ${constituency.Name}`
                              }).appendTo($data);
                              console.dir(constituency);
                              $.ajax(`https://data.parliament.scot/api/MemberElectionConstituencyStatuses/${constituency.ID}`, {
                                  method: 'GET',
                                  dataType: "json",
                              }).done((data) => {
                                  const memberElection = data;
                                  console.dir(memberElection);
                                  $.ajax(`https://data.parliament.scot/api/members/${memberElection.PersonID}`, {
                                      method: 'GET',
                                      dataType: "json",
                                  }).done((data) => {
                                      const person = data;
                                      console.dir(person);
                                      $("<span>", {
                                          class: "mspPersonId",
                                          text: `Person ID: ${person.PersonID}`
                                      }).appendTo($data);
                                      $("<span>", {
                                          class: "mspName",
                                          text: `Name: ${person.ParliamentaryName}`
                                      }).appendTo($data);
                                      $("<span>", {
                                          class: "mspDOB",
                                          text: `D.O.B: ${(person.BirthDateIsProtected) ? "Protected" : formatDate(new Date(person.BirthDate))}`
                                      }).appendTo($data);
                                      $("<span>", {
                                          class: "mspRegionId",
                                          text: `Region ID: ${constituency.RegionID}`
                                      }).appendTo($data);
                                      $("<span>", {
                                          class: "mspValidFrom",
                                          text: `Valid From: ${formatDate(new Date(memberElection.ValidFromDate))}`
                                      }).appendTo($data);
									  $("<span>", {
                                          class: "mspValidFrom",
                                          text: `Valid From: ${formatDate(new Date(memberElection.ValidFromDate))}`
                                      }).appendTo($data);
                                      $("<span>", {
                                          class: "mspValidUntil",
                                          text: `Valid Until: ${formatDate(new Date(memberElection.ValidUntilDate))}`
                                      }).appendTo($data);
                                      $("<span>", {
                                          class: "mspElectionStatus",
                                          text: `Election Status ID: ${memberElection.ElectionStatusID}`
                                      }).appendTo($data);
                                      $("<span>", {
                                          class: "mspElectionReasonDate",
                                          text: `Election Reason Date ID: ${memberElection.ElectionReasonDateID}`
                                      }).appendTo($data);
                                  });
                              });
                          });
                      }).fail((error) => {
                          $("<span>", {
                              class: "error",
                              text: "Invalid postcode"
                          }).appendTo($data);
                          console.error(error);
                      });
                  }
              });
            });
         
         var modal = document.getElementById("myModal");
		 
		 var buttonYes = document.getElementById("yes");

		 var buttonNo = document.getElementById("no");
         
         var img = document.getElementById("myImg");
         var img2 = document.getElementById("myImg2");
         var img3 = document.getElementById("myImg3");
         var img4 = document.getElementById("myImg4");
         
         var span2 = document.getElementsByClassName("close")[0];
         
         img.onclick = function() {
         modal.style.display = "block";
         }
         
         img2.onclick = function() {
         modal.style.display = "block";
         }
         
         img3.onclick = function() {
         modal.style.display = "block";
         }
         
         img4.onclick = function() {
         modal.style.display = "block";
         }
         
         span2.onclick = function() {
         modal.style.display = "none";
         }
		 
		 buttonYes.onclick = function() {
		 alert("Now taking you to the selected platform");
		 }
		
		 buttonNo.onclick = function() {
		 modal.style.display = "none";
		 }
         
         window.onclick = function(event) {
         if (event.target == modal) {
          modal.style.display = "none";
         }
         }
		 
		function myFunction() {
		  var x = document.getElementById("demo");
		  if (x.className.indexOf("w3-show") == -1) {
			x.className += " w3-show";
		  } else { 
			x.className = x.className.replace(" w3-show", "");
		  }
		}
		
      </script>
   </body>
</html>