<!DOCTYPE html>
<html>
   <head>
      <meta content="width=device-width, initial-scale=1" name="viewport">
      <title></title>
      <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet">
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      <link href="style.css" media="all" rel="stylesheet" type="text/css">
   </head>
   <body>
      <div class="header">
         <img src="images/logowt.png">
         <p>Disovery Scotland</p>
      </div>
      <div id="wrapper">
         <div id="header-wrapper">
            <div class="container-h" id="header">
               <div id="logo">
                  <h1><img src="images/logogt.png">Welcome to Discovery Scotland</h1>
               </div>
            </div>
            <div class="container-m col-12 col-s-12" id="menu-job" class="w3-bar w3-red">
               <ul>
                  <li>
                     <a href="home.html" class="w3-hide-small">Home</a>
                  </li>
                  <li class="current_page_item">
                     <a class="active" href="jobinfo.php" class="w3-bar-item w3-button">Job Info</a>
                  </li>
                  <li>
                     <a href="msp.php" class="w3-hide-small">MSP Details</a>
                  </li>
                  <li>
                     <a href="rop.php" class="w3-hide-small">Rate of Pay</a>
                  </li>
				  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="myFunction()">&#9776;</a>
               </ul>
            </div>
         </div>
		 <div id="demo" class="w3-bar-block w3-indigo w3-hide w3-hide-large w3-hide-medium">
		  <a href="home.html" class="w3-bar-item w3-button">Home</a>
		  <a href="msp.php" class="w3-bar-item w3-button">MSP Details</a>
		  <a href="rop.php" class="w3-bar-item w3-button">Rate of Pay</a>
		</div>
         <div class="container-s col-12 col-s-12" id="page">
            <div id="content">
               <div class="post">
                  <p class="jobinfo">Job Information</p>
                  <hr class="jobinfopage">
                  <p class="customerrequest">Please enter postcode below to reveal Job information for entered area</p>
                  <input id="mySearchField" name="search" placeholder="Enter Postcode" type="text"><button id="mySearchButton" class="sbmt">Search</button><br>
                  <p class="data"></p>
               </div>
			   <div id="lightbox" >
                  <div id="overlay"> </div>
                  <img id="largeImg" src="" alt="" /> 
                  <span id="caption"></span>
                  <span id="close">&times;</span>
               </div>
            </div>
            <div id="sidebar1">
               <div>
                  <h2>Contact Information</h2>
                  <ul class="style2">
                     <li class="first">
                        <p>Not finding what you are looking for or have any questions that you need answering? Feel free to contact us via telephone or email.</p>
                        <p><img src="images/email.png"> info@discoveryscotland.co.uk</p>
                        <p><img src="images/phone.png"> 0141 117 6669</p>
                     </li>
                     <li>
                        <h3>Social Media</h3>
                        <p class="connect">Connect:<img id="myImg" src="images/twitter.png"><img id="myImg2" src="images/insta.png"><img id="myImg3" src="images/fb.png"><img id="myImg4" src="images/youtube.png"></p>
                        <div id="myModal" class="modal">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <span class="close">&times;</span>
                                 <h4>
                                    <center>You are leaving Discovery Scotland's Website to visit our selected Social Media platform?</center>
                                 </h4>
                              </div>
                              <div class="modal-body">
                                 <p>
                                 <center>
                                 Would you like to proceed with this?
                                 <center>
                                 </p>
                                 <button class="yesno" id="yes"><span>Yes</span></button>
                                 <button class="yesno" id="no"><span>No</span></button>
                              </div>
                              <div class="modal-footer">
                                 <h5>&copy; DISCOVERY SCOTLAND 2019</h5>
                              </div>
                           </div>
                        </div>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="footer">
            <p><img src="images/logobt.png">&copy; DISCOVERY SCOTLAND 2019</p>
         </div>
      </div>
      <script>
         $(function() {
         
          var _mySearchButton = document.getElementById("mySearchButton");
          _mySearchButton.onclick = getData;
         
          function getData(){
          var _mySearchField = document.getElementById("mySearchField");
              $.ajax({
              url: "http://api.lmiforall.org.uk/api/v1/census/jobs_breakdown?area="+_mySearchField.value,
             method: "GET",
              dataType: "json",
              success: function(data) {
                  var str = "";          
                 for(var i= 0; i < data.jobsBreakdown.length; i++){
         
                   str +='Job Title : '+data.jobsBreakdown[i].description+' <br> Total Number of People Engaged in Occupency : '+data.jobsBreakdown[i].value+' <br> Percentage of Occupancies in Area : '+data.jobsBreakdown[i].percentage.toPrecision(2)+'% <br><br>';
                 }
                $("div.post p.data").html(str);
              },
                  error: function(nodata) {
                  alert("Data not acceptable, please try again"); //*Note, I added two different types of ways to display information informing the user's inputted data is not acceptable, I did this to show there are multiple ways to make the website interactive 
                  }
              });
          }
         });
         
         var modal = document.getElementById("myModal");
		 
		 var buttonYes = document.getElementById("yes");

		 var buttonNo = document.getElementById("no");
         
         var img = document.getElementById("myImg");
         var img2 = document.getElementById("myImg2");
         var img3 = document.getElementById("myImg3");
         var img4 = document.getElementById("myImg4");
         
         var span = document.getElementsByClassName("close")[0];
         
         img.onclick = function() {
         modal.style.display = "block";
         }
         
         img2.onclick = function() {
         modal.style.display = "block";
         }
         
         img3.onclick = function() {
         modal.style.display = "block";
         }
         
         img4.onclick = function() {
         modal.style.display = "block";
         }
         
         span.onclick = function() {
         modal.style.display = "none";
         }
         
		 buttonYes.onclick = function() {
		 alert("Now taking you to the selected platform");
		}
		
		 buttonNo.onclick = function() {
		 modal.style.display = "none";
		 }
		 
         window.onclick = function(event) {
         if (event.target == modal) {
         modal.style.display = "none";
         }
         }
		 
		function myFunction() {
		  var x = document.getElementById("demo");
		  if (x.className.indexOf("w3-show") == -1) {
			x.className += " w3-show";
		  } else { 
			x.className = x.className.replace(" w3-show", "");
		  }
		}
      </script>
   </body>
</html>